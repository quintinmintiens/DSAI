# Labs module 2: Analysis of one variable

Copy the demo and lab assignment notebooks to your Google Colab environment!
