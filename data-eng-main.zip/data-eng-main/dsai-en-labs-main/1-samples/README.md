# Labs module 1: Basic Concepts, Sampling

Copy the demo and lab assignment notebooks to your Google Colab environment!
